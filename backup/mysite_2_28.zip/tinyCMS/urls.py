from django.conf.urls.defaults import *

import os.path

# Uncomment the next two lines to enable the admin:
from django.contrib import admin
admin.autodiscover()

urlpatterns = patterns('',
    # Example:
    # (r'^tinyCMS/', include('tinyCMS.foo.urls')),

    # Uncomment the admin/doc line below and add 'django.contrib.admindocs' 
    # to INSTALLED_APPS to enable admin documentation:
    # (r'^admin/doc/', include('django.contrib.admindocs.urls')),

        
    # Uncomment the next line to enable the admin:
    (r'^admin/', include(admin.site.urls)),
    #(r'^tiny_mce/(?P<path>.*)$', 'django.views.static.serve', {'document_root':os.path.join(os.path.dirname(__file__),'tiny_mce').replace('\\','/')}),
    (r'^tiny_mce/(?P<path>.*)$', 'django.views.static.serve', {'document_root': '/home/realjld/tiny/mysite/tinyCMS/tiny_mce'}),
    (r'^search/$', 'tinyCMS.search.views.search'),

    # weBlog
    (r'^weblog/$', 'weBlog.views.entries_index'),
    # (r'^weblog/(?P<year>\d{4})/(?P<month>\w{3})/(?P<day>\d{2})/(P?<slug>[-\w]+)/$', 'weBlog.views.entry_detail'),
    (r'^weblog/(?P<year>\d{4})/(?P<month>\w{3})/(?P<day>\d{2})/(?P<slug>[-\w]+)/$', 'weBlog.views.entry_detail'),


    # (r'', include('django.contrib.flatpages.urls')),
)
