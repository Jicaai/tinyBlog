﻿This file is meant for developers wishing to hack on this project. If thats
you, welcome :)

First of all, there is no development plan, and mostly its pretty straightforward
Python hacking. If you want something from the del.icio.us service that is not
here yet, just hack and introduce yourself and your ideas at the `project homepage`_.


What's there to do
------------------
Read the TODO/FIXME/XXX's throughout the code comments or 
have a look at the `issues`_ listed at the home page.

Here are the basic guidelines:

- Use 4 spaces for indent, use whitespace. Keep it readable.
- Test your code. 
- Use the issue list to get comments on your proposed changes.


.. _project homepage: http://code.google.com/p/pydelicious/
.. _issues: http://code.google.com/p/pydelicious/issues/
